import React from 'react';
import NavigationPanel from "../NavigationPanel";
import '../userDash.css'
import { ToastContainer } from "react-toastify";

const AllTransactions = () => {
  return (
    <>
      <div className="DashboardPagesContainer">
        <NavigationPanel />

        <div id="main-content">
          <div>this is all transaction page</div>
        </div>
      </div>
      <ToastContainer />

    </>
  )
};

export default AllTransactions;
