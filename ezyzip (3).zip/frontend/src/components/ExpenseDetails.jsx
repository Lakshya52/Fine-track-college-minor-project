import React from 'react'

function ExpenseDetails({ incomeAmt, expenseAmt }) {
    return (
        <div>
            
            {/* Show Income & Expense amount */}
            <div className="amounts-container">
                
                Your Balance is : &nbsp;
                <span className="income-amount">₹{incomeAmt - expenseAmt}</span>
                <br />
                Income :&nbsp;
                <span className="income-amount">₹{incomeAmt}</span> <br />
                Expense:&nbsp;
                <span className="expense-amount">₹{expenseAmt}</span>
            </div>
        </div>
    )
}

export default ExpenseDetails