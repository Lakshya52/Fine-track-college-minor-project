import React from 'react'

import '../../stylesheets/Footer.css'

const Footer = () => {
  return (
    <>
    <footer>
      &copy; Fine-Track | Developed and Designed by Lakshya | BCIIT Minor project 2024
    </footer>
    </>
  )
}

export default Footer